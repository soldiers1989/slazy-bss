﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.IO;
using System.Net;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

public partial class _Default : System.Web.UI.Page 
{
    public static string sname = System.Configuration.ConfigurationManager.AppSettings["sname"];
    public static string spwd = System.Configuration.ConfigurationManager.AppSettings["spwd"];
    public static string scorpid = System.Configuration.ConfigurationManager.AppSettings["scorpid"];
    public static string sprdid = System.Configuration.ConfigurationManager.AppSettings["sprdid"];
    public static string SmsMmsWebService = System.Configuration.ConfigurationManager.AppSettings["SmsMmsWebService"];

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void butSubmit_Click(object sender, EventArgs e)
    {
        string tels = this.toList.Text.Trim();
        //处理上传文件
        HttpFileCollection fileColllection = HttpContext.Current.Request.Files;
        System.Text.StringBuilder strMsg = new System.Text.StringBuilder();
        List<byte> byteList = new List<byte>();
        try
        {
            for (int iFile = 0; iFile < fileColllection.Count; iFile++)
            {
                //检查文件扩展名字
                HttpPostedFile postedFile = fileColllection[iFile];
                string fileExtension;
                string fileName = System.IO.Path.GetFileName(postedFile.FileName);
                if (!string.IsNullOrEmpty(fileName))
                {
                    fileExtension = System.IO.Path.GetExtension(fileName);
                    strMsg.Append("上传的文件类型：" + postedFile.ContentType.ToString() + "<br>");
                    strMsg.Append("客户端文件地址：" + postedFile.FileName + "<br>");
                    strMsg.Append("上传文件的文件名：" + fileName + "<br>");
                    strMsg.Append("上传文件的扩展名：" + fileExtension + "<br><hr>");
                    string savePath = HttpContext.Current.Request.MapPath(".") + "/upload/" + fileName;
                    postedFile.SaveAs(savePath);
                    byteList.AddRange(PackFiles.PackFiles.MakeTmsContent(savePath));
                }
            }

        }
        catch (System.Exception Ex)
        {

        }

        byte[] mmsData = new byte[byteList.Count];
        byteList.CopyTo(mmsData);
        UTF8Encoding encoding = new UTF8Encoding();
        SoapBase64Binary base64Binary = new SoapBase64Binary(mmsData);

        string postDataStrTpl = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><SubmitMms xmlns=\"http://MmsWebInterface.org/\"><UserID>{0}</UserID><Password>{1}</Password><CorpID>{2}</CorpID><PrdID>{3}</PrdID><DstID>{4}</DstID><MmsSubject>{5}</MmsSubject><TmsBuffer>{6}</TmsBuffer></SubmitMms></soap:Body></soap:Envelope>";
        string postDataStr = string.Format(postDataStrTpl, sname, spwd, scorpid, sprdid, tels, "彩信title", base64Binary.ToString());
       
        byte[] postData = encoding.GetBytes(postDataStr);

        HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(SmsMmsWebService);
        myRequest.Method = "POST";
        
        myRequest.ContentType = "text/xml; charset=utf-8";
        myRequest.Headers.Add("SOAPAction", "http://MmsWebInterface.org/SubmitMms");
        myRequest.ContentLength = postData.Length;

        Stream newStream = myRequest.GetRequestStream();
        // Send the data.
        newStream.Write(postData, 0, postData.Length);
        newStream.Flush();
        newStream.Close();

        HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
        if (myResponse.StatusCode == HttpStatusCode.OK)
        {
            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
            upfileMmsMsg.Text = reader.ReadToEnd();
            //反序列化upfileMmsMsg.Text
        }

        upfileMsg.Text = strMsg.ToString();
    }
}
