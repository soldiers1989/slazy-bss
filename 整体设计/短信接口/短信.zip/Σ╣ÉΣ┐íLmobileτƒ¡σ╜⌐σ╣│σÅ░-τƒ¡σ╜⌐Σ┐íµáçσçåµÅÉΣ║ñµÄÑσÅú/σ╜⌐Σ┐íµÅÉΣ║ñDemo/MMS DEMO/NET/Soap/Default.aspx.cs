﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SmsMmsWebService;

public partial class _Default : System.Web.UI.Page 
{
    public static MmsWebInterface service = new MmsWebInterface();
    public static string sname = System.Configuration.ConfigurationManager.AppSettings["sname"];
    public static string spwd = System.Configuration.ConfigurationManager.AppSettings["spwd"];
    public static string scorpid = System.Configuration.ConfigurationManager.AppSettings["scorpid"];
    public static string sprdid = System.Configuration.ConfigurationManager.AppSettings["sprdid"];

    public CSubmitState state;

    protected void Page_Load(object sender, EventArgs e)
    {
        //CSubmitState state = service.SubmitMms();
    }
    protected void butSubmit_Click(object sender, EventArgs e)
    {
        string tels = this.toList.Text.Trim();
        //处理上传文件
        HttpFileCollection fileColllection = HttpContext.Current.Request.Files;
        System.Text.StringBuilder strMsg = new System.Text.StringBuilder();
        List<byte> byteList = new List<byte>();
        try
        {
            for (int iFile = 0; iFile < fileColllection.Count; iFile++)
            {
                //检查文件扩展名字
                HttpPostedFile postedFile = fileColllection[iFile];
                string fileExtension;
                string fileName = System.IO.Path.GetFileName(postedFile.FileName);
                if (!string.IsNullOrEmpty(fileName))
                {
                    fileExtension = System.IO.Path.GetExtension(fileName);
                    strMsg.Append("上传的文件类型：" + postedFile.ContentType.ToString() + "<br>");
                    strMsg.Append("客户端文件地址：" + postedFile.FileName + "<br>");
                    strMsg.Append("上传文件的文件名：" + fileName + "<br>");
                    strMsg.Append("上传文件的扩展名：" + fileExtension + "<br><hr>");
                    string savePath = HttpContext.Current.Request.MapPath(".") + "/upload/" + fileName;
                    postedFile.SaveAs(savePath);
                    byteList.AddRange(PackFiles.PackFiles.MakeTmsContent(savePath));
                }
            }
            
        }
        catch (System.Exception Ex)
        {
            
        }

        byte[] newArray = new byte[byteList.Count];
        byteList.CopyTo(newArray);

        state = service.SubmitMms(sname, spwd, scorpid, sprdid, tels, "测试彩信", newArray);

        upfileMsg.Text = strMsg.ToString();
        upfileMmsMsg.Text = "MsgID:" + state.MsgID + "<br/>MsgState:" + state.MsgState + "<br/>State:" + state.State;
    }
}
