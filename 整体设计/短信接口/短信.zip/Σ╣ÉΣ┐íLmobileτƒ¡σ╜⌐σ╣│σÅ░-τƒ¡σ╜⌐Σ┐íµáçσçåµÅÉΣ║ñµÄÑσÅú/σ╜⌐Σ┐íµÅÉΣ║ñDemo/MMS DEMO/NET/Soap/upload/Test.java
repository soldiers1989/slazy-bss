package com.mycompany.component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class Test {
	public static void main(String args[]) {
		test3();
	}  

	public static void test3()  {
        try
        {
            //����POST����
            URL url=new URL("http://wt.wzldmedia.cn/submitdata/Service.asmx/g_GetRemain");
            HttpURLConnection conn=(HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            
            String postdata="sname=dlhand005&spwd=123456&scorpid=&sprdid=802";
			conn.setRequestProperty("Content-Length", postdata.length())
            OutputStreamWriter out=new OutputStreamWriter(conn.getOutputStream(),"UTF-8"); 
            out.write(postdata);
            out.flush();
            out.close();

            //��ȡ��Ӧ״̬
            //System.out.println("conn.getResponseCode="+conn.getResponseCode());
            System.out.println("conn.HttpURLConnection.HTTP_OK="+HttpURLConnection.HTTP_OK);
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                System.out.println("connect failed!");
            }
            //��ȡ��Ӧ������
            String line,result="";
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
            while ((line=in.readLine())!=null)
            {
                result+=line+"\n";
            }
            in.close();
            System.out.println(result);
        }
        catch (IOException e)
        {
            e.printStackTrace(System.out);
        }
	}
	

	  
	  
}
