using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PackFiles
{
    public class PackFiles
    {
        public static byte[] MakeTmsContent(String fileWholeName)
        {
            byte[] buffer = null;
            FileInfo finfo = new FileInfo(fileWholeName);
            if (!finfo.Exists)
                return buffer;
            using (MemoryStream ms = new MemoryStream())
            {
                using (BinaryWriter wr = new BinaryWriter(ms))
                {
                    using (FileStream fs = new FileStream(finfo.FullName, FileMode.Open))
                    {
                        using (BinaryReader bread = new BinaryReader(fs))
                        {
                            int filelen = (int)fs.Length;
                            byte[] fname = Encoding.ASCII.GetBytes(finfo.Name + "\0");
                            byte[] content = bread.ReadBytes(filelen);
                            wr.Write(fname, 0, fname.Length);
                            wr.Write(filelen);
                            wr.Write(content, 0, content.Length);
                            bread.Close();
                        }
                        fs.Close();
                    }
                    wr.Close();
                }
                buffer = ms.ToArray();
                ms.Close();
            }
            return buffer;
        }
    }
}
