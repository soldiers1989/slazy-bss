<?php
include_once('mms.php');
$target = "http://cf.51welink.com/submitdata/MmsWebInterface.asmx";
$SOAPAction = "http://MmsWebInterface.org/SubmitMms";
$data = packFile('./mmsfile/image.gif');//多个文件用"."连接起来就可以了
$data .= packFile('./mmsfile/txt.txt');//多个文件用"."连接起来就可以了
if($data != null) {
	//替换成自己的测试账号,参数顺序和wenservice对应
    $post_data = craetePostData('kwsm', 'kwsm', '', '108', '13910862579', 'mmstitle', $data);
    echo $gets = Post($post_data, $target, $SOAPAction);
	//请自己实现返回字符串解析和业务逻辑
}
?>
