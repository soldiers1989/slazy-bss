#python3.4环境短信提交demo

import urllib.request
import urllib.error
import xml.dom.minidom

url = "http://cf.51welink.com/submitdata/Service.asmx/g_Submit"
#定义需要进行发送的数据
param = {'sname':'kwsm',        #账号
        'spwd':'kwsm',          #密码  
        'scorpid':'',           #企业代码
        'sprdid':'1011618',     #产品编号
        'sdst':'18810013110',   #手机号码
        'smsg':'短信内容'}       #短信内容
data = urllib.parse.urlencode(param).encode(encoding='UTF8')
#定义头
headers = {"Content-Type":"application/x-www-form-urlencoded"}
#开始提交数据
req = urllib.request.Request(url, data, headers)   
response = urllib.request.urlopen(req)
#获取返回数据
result = response.read().decode('utf8')

#自行解析返回结果xml，对应结果参考文档
dom = xml.dom.minidom.parseString(result)
root = dom.documentElement
State = root.getElementsByTagName("State")
MsgID = root.getElementsByTagName("MsgID")
MsgState = root.getElementsByTagName("MsgState")
Reserve = root.getElementsByTagName("Reserve")
print(State[0].firstChild.data)  #State值为0表示提交成功
print(MsgID[0].firstChild.data)
print(MsgState[0].firstChild.data)
print(Reserve[0].firstChild.data)
