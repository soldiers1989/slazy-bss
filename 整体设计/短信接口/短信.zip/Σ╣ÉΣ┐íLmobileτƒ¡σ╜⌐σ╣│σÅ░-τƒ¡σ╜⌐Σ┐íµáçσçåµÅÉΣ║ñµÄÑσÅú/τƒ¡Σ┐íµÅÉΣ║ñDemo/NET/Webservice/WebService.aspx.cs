﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _WebService : System.Web.UI.Page 
{
    public static WebReference.Service1 service = new WebReference.Service1();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void ButSubmit_Click(object sender, EventArgs e)
    {
        string sname = this.TxtSname.Text.Trim();
        string spwd = this.TxtSpwd.Text.Trim();
        string scorpid = this.TxtScorpid.Text.Trim();
        string sprdid = this.TxtSprdid.Text.Trim();
        string sdst = this.TxtSdst.Text.Trim();
        string smsg = this.TxtSmsg.Text.Trim();

        WebReference.CSubmitState state =  service.g_Submit(sname, spwd, scorpid, sprdid, sdst, smsg);

        //您的逻辑
        this.LabelRetMsg.Text = state.MsgID + ":" + state.MsgState;

    }
}
