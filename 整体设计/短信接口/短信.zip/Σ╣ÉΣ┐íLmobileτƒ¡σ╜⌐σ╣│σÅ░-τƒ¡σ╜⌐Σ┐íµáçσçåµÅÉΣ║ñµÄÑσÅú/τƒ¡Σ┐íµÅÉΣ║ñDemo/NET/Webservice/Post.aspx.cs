﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Post : System.Web.UI.Page
{
    public static string PostUrl = ConfigurationManager.AppSettings["WebReference.Service.PostUrl"];
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButSubmit_Click(object sender, EventArgs e)
    {
        string sname = this.TxtSname.Text.Trim();
        string spwd = this.TxtSpwd.Text.Trim();
        string scorpid = this.TxtScorpid.Text.Trim();
        string sprdid = this.TxtSprdid.Text.Trim();
        string sdst = this.TxtSdst.Text.Trim();
        string smsg = this.TxtSmsg.Text.Trim();

        string postStrTpl = "sname={0}&spwd={1}&scorpid={2}&sprdid={3}&sdst={4}&smsg={5}";

        UTF8Encoding encoding = new UTF8Encoding();
        byte[] postData = encoding.GetBytes(string.Format(postStrTpl, sname, spwd, scorpid, sprdid, sdst, smsg));

        HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(PostUrl);
        myRequest.Method = "POST";
        myRequest.ContentType = "application/x-www-form-urlencoded";
        myRequest.ContentLength = postData.Length;

        Stream newStream = myRequest.GetRequestStream();
        // Send the data.
        newStream.Write(postData, 0, postData.Length);
        newStream.Flush();
        newStream.Close();

        HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
        if (myResponse.StatusCode == HttpStatusCode.OK)
        {
            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
            LabelRetMsg.Text = reader.ReadToEnd();
            //反序列化upfileMmsMsg.Text
            //实现自己的逻辑
        }
        else
        {
            //访问失败
        }
    }
}
