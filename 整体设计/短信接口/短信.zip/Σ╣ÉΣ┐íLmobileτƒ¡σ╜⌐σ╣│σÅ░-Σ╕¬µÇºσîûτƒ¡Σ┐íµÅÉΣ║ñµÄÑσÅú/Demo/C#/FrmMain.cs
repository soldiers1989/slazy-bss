﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndividuationSubmitService_Demo.IndividService;

namespace IndividuationSubmitService_Demo
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //提交个性短息
            IndividService.IndividuationServiceSoapClient
             Service = new IndividuationServiceSoapClient();
            CSubmitState SubmitState = Service.IndividuationSmsCommit(
                                                  txtUser.Text.Trim(), //提交用户
                                                  txtPassword.Text.Trim(), //密码
                                                  txtCorpID.Text.Trim(), //企业代码
                                                  txtProductID.Text.Trim(), //产品编号
                                                  txtKey.Text.Trim(), //用户自定义参数
                                                  txtVariable.Text.Trim(), //短信模板
                                                  txtTemplate.Text.Trim()  //短信变量
                                                  );
            if (SubmitState.State == 0)
            {
                MessageBox.Show("提交成功！" + Environment.NewLine + "MsgID: " + SubmitState.MsgID + Environment.NewLine + "MsgState：" + SubmitState.MsgState, "提交返回结果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("提交失败！" + Environment.NewLine + "MsgID: " + SubmitState.MsgID + Environment.NewLine + "MsgState：" + SubmitState.MsgState, "提交返回结果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}
