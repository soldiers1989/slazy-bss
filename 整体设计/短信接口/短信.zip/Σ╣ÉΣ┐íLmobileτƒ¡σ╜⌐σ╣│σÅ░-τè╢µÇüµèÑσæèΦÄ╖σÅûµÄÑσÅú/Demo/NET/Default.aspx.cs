﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CSharpUtils.Log4netUtil;

namespace TestWebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string AccountID = Request["AccountID"] ?? string.Empty;
                string MsgID = Request["MsgID"] ?? string.Empty;
                string MobilePhone = Request["MobilePhone"] ?? string.Empty;
                string ReportResultInfo = Request["ReportResultInfo"] ?? string.Empty;
		string ReportState= Request["ReportState"] ?? string.Empty;
                string ReportTime = Request["ReportTime"] ?? string.Empty;
                string SendResultInfo = Request["SendResultInfo"] ?? string.Empty;
                string SendState = Request["SendState"] ?? string.Empty;
				string SendedTime = Request["SendedTime"] ?? string.Empty;
				string SPNumber = Request["SPNumber"] ?? string.Empty;
                string result = string.Format("AccountID ={0}|MsgID ={1}|MobilePhone={2}|ReportResultInfo={3}|ReportState ={4}|ReportTime ={5}|SendResultInfo={6}|SendState={7}|SendedTime={8}|SPNumber={9}", AccountID, MsgID, MobilePhone, ReportResultInfo,ReportState,ReportTime,SendResultInfo,SendState,SendedTime,SPNumber);
                Response.Write(result);
                log4netWriter.WriteLog(new LogEventArgs(typeof(Default), LogLevel.INFO, result, null));
            }
            catch (Exception ex)
            {
                log4netWriter.WriteLog(new LogEventArgs(typeof(Default), LogLevel.ERROR, null, ex));
            }
        }
    }
}