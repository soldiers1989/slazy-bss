<?php
$AccountID = $_REQUEST['AccountID'];
$MsgID = $_REQUEST['MsgID'];
$MobilePhone = $_REQUEST['MobilePhone'];
$ReportResultInfo = $_REQUEST['ReportResultInfo'];
$ReportState = $_REQUEST['ReportState'];
$ReportTime = $_REQUEST['ReportTime'];
$SendResultInfo = $_REQUEST['SendResultInfo'];
$SendState = $_REQUEST['SendState'];
$SendedTime = $_REQUEST['SendedTime'];
$SPNumber = $_REQUEST['SPNumber'];

//您的业务逻辑
//.......
//demo
//记LOG的例子,主要是为了$up_msg编码的处理
//请保存该文件的时候 编码方式:utf-8
$old_log = '';
if(file_exists("php-utf8-debug.log")){
	$old_log = file_get_contents("php-utf8-debug.log");
}
$up_msg = "AccountID=".$AccountID."&MsgID=".$MsgID."&MobilePhone=".$MobilePhone."&ReportResultInfo=".$ReportResultInfo."&ReportState=".$ReportState."&ReportTime=".$ReportTime."&SendResultInfo=".$SendResultInfo."&SendedTime"=.$SendedTime."&SendState=".$SendState."&SPNumber=".$SPNumber."\r\n";
$new_log = $old_log.$up_msg;
file_put_contents("php-utf8-debug.log",$new_log);
echo 'ok';
?>