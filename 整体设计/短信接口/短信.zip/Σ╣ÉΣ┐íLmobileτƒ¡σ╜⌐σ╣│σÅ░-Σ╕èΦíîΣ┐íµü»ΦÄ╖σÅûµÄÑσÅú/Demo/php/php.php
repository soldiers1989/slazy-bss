<?php
$msgid = $_REQUEST['MsgId'];
$up_num = $_REQUEST['Up_YourNum'];
$up_servnum = $_REQUEST['Up_UserTel'];
$up_msg = $_REQUEST['Up_UserMsg'];

//您的业务逻辑
//.......
//demo
//记LOG的例子,主要是为了$up_msg编码的处理
//请保存该文件的时候 编码方式:utf-8
$old_log = '';
if(file_exists("php-utf8-debug.log")){
	$old_log = file_get_contents("php-utf8-debug.log");
}
$up_msg = "MsgId=".$msgid."&Up_YourNum=".$up_num."&Up_UserTel=".$up_servnum."&Up_UserMsg=".$up_msg."\r\n";
$new_log = $old_log.$up_msg;
file_put_contents("php-utf8-debug.log",$new_log);
echo 'ok';
?>