﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CSharpUtils.Log4netUtil;

namespace TestWebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string MsgID = Request["MsgId"] ?? string.Empty;
                string Up_YourNum = Request["Up_YourNum"] ?? string.Empty;
                string Up_UserTel = Request["Up_UserTel"] ?? string.Empty;
                string Up_UserMsg = Request["Up_UserMsg"] ?? string.Empty;
                string result = string.Format("MsgId ={0}|Up_YourNum={1}|Up_UserTel={2}|Up_UserMsg ={3}", MsgID, Up_YourNum, Up_UserTel, Up_UserMsg);
                Response.Write(result);
                log4netWriter.WriteLog(new LogEventArgs(typeof(Default), LogLevel.INFO, result, null));
            }
            catch (Exception ex)
            {
                log4netWriter.WriteLog(new LogEventArgs(typeof(Default), LogLevel.ERROR, null, ex));
            }
        }
    }
}